var searchData=
[
  ['major_0',['major',['../structapr__version__t.html#a0ae64fee85387834ab76d9f9288373ab',1,'apr_version_t']]],
  ['minor_1',['minor',['../structapr__version__t.html#aab0a1e8362517416389631bceeeedbad',1,'apr_version_t']]],
  ['mm_2',['mm',['../structapr__mmap__t.html#abcc62d7e7c8187311e6619faf0d44f19',1,'apr_mmap_t']]],
  ['mtime_3',['mtime',['../structapr__finfo__t.html#afc3bec0f6b3b10160428ba5602a41c60',1,'apr_finfo_t']]]
];
