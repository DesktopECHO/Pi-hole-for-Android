#if defined(HAVE_CONFIG_H)
#include <config_ac.h>
#endif

#include "../config.c"
