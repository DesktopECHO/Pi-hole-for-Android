var searchData=
[
  ['platform_20definitions_0',['Platform Definitions',['../group__apr__platform.html',1,'']]],
  ['poll_20options_1',['Poll options',['../group__pollopts.html',1,'']]],
  ['poll_20routines_2',['Poll Routines',['../group__apr__poll.html',1,'']]],
  ['pollset_20flags_3',['Pollset Flags',['../group__pollflags.html',1,'']]],
  ['pool_20cleanup_20functions_4',['Pool Cleanup Functions',['../group___pool_cleanup.html',1,'']]],
  ['pool_20debugging_20functions_5',['Pool Debugging functions',['../group___pool_debug.html',1,'']]],
  ['portability_20routines_6',['Portability Routines',['../group__apr__portabile.html',1,'']]],
  ['process_20locking_20routines_7',['Process Locking Routines',['../group__apr__proc__mutex.html',1,'']]]
];
