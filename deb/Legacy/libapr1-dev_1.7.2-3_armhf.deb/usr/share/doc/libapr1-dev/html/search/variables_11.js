var searchData=
[
  ['user_0',['user',['../structapr__finfo__t.html#ab79d14bd50f50662d29ad433166c4bc5',1,'apr_finfo_t']]]
];
