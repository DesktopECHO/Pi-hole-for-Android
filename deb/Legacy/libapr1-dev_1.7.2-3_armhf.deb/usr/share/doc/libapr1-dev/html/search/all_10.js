var searchData=
[
  ['s_0',['s',['../unionapr__descriptor.html#a39a15be8be084afadfa173810b346f6c',1,'apr_descriptor']]],
  ['s_5faddr_1',['s_addr',['../structin__addr.html#a1bf09b20f0531edf5da627f712561108',1,'in_addr']]],
  ['sa_2',['sa',['../structapr__sockaddr__t.html#a6aa3866aed7f527bf4f988b6dc9b5675',1,'apr_sockaddr_t']]],
  ['salen_3',['salen',['../structapr__sockaddr__t.html#aef1d2a482f85eeab7b6bf0a7732a087a',1,'apr_sockaddr_t']]],
  ['servname_4',['servname',['../structapr__sockaddr__t.html#a668335161a8347b9a34c600bff80b52f',1,'apr_sockaddr_t']]],
  ['shared_20memory_20routines_5',['Shared Memory Routines',['../group__apr__shm.html',1,'']]],
  ['signal_20handling_6',['Signal Handling',['../group__apr__signal.html',1,'']]],
  ['sin_7',['sin',['../structapr__sockaddr__t.html#a7d5cf0290260c3c448360fc819b28714',1,'apr_sockaddr_t']]],
  ['size_8',['size',['../structapr__finfo__t.html#a3e47a673c5b82a25a783a732dee6f946',1,'apr_finfo_t::size()'],['../structapr__mmap__t.html#a274aea0906a4b674e1642ac9e81966c7',1,'apr_mmap_t::size()']]],
  ['skip_20list_20implementation_9',['Skip list implementation',['../group__apr__skiplist.html',1,'']]],
  ['skip_5fend_10',['skip_end',['../structapr__getopt__t.html#ae9e7e6eb1576820c7dc6e589cc3a28b7',1,'apr_getopt_t']]],
  ['skip_5fstart_11',['skip_start',['../structapr__getopt__t.html#a0cd41eedf9ed82bf5d9dcc3491ee67dd',1,'apr_getopt_t']]],
  ['snprintf_20implementations_12',['snprintf implementations',['../group___a_p_r___strings___snprintf.html',1,'']]],
  ['socket_20option_20definitions_13',['Socket option definitions',['../group__apr__sockopt.html',1,'']]],
  ['stat_20functions_14',['Stat Functions',['../group__apr__file__stat.html',1,'']]],
  ['status_20value_20tests_15',['Status Value Tests',['../group___a_p_r___s_t_a_t_u_s___i_s.html',1,'']]],
  ['string_20routines_16',['String routines',['../group__apr__strings.html',1,'']]]
];
