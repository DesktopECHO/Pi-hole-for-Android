var searchData=
[
  ['f_0',['f',['../unionapr__descriptor.html#a69d605f2bb33b05ceedb3d95b744ca7e',1,'apr_descriptor']]],
  ['family_1',['family',['../structapr__sockaddr__t.html#ac17f6e803928cfc29069a6e62dcb3a52',1,'apr_sockaddr_t::family()'],['../structapr__os__sock__info__t.html#aa29fd0cf57b0b5e3559961f068fa8b7e',1,'apr_os_sock_info_t::family()']]],
  ['file_20attribute_20flags_2',['File Attribute Flags',['../group__apr__file__attrs__set__flags.html',1,'']]],
  ['file_20i_2fo_20handling_20functions_3',['File I/O Handling Functions',['../group__apr__file__io.html',1,'']]],
  ['file_20information_4',['File Information',['../group__apr__file__info.html',1,'']]],
  ['file_20lock_20types_5',['File Lock Types',['../group__apr__file__lock__types.html',1,'']]],
  ['file_20open_20flags_2froutines_6',['File Open Flags/Routines',['../group__apr__file__open__flags.html',1,'']]],
  ['file_20permissions_20flags_7',['File Permissions flags',['../group__apr__file__permissions.html',1,'']]],
  ['file_20seek_20flags_8',['File Seek Flags',['../group__apr__file__seek__flags.html',1,'']]],
  ['filehand_9',['filehand',['../structapr__finfo__t.html#a7858e3d9c5f6ed062d9ff7f5c79b6336',1,'apr_finfo_t']]],
  ['filename_20matching_20functions_10',['Filename Matching Functions',['../group__apr__fnmatch.html',1,'']]],
  ['filepath_20manipulation_20functions_11',['Filepath Manipulation Functions',['../group__apr__filepath.html',1,'']]],
  ['filetype_12',['filetype',['../structapr__finfo__t.html#a274ae0dd60b59182c2e0134bc9a09a20',1,'apr_finfo_t']]],
  ['first_5favail_13',['first_avail',['../structapr__memnode__t.html#a863e7980225e46678881271c4c803e4c',1,'apr_memnode_t']]],
  ['fname_14',['fname',['../structapr__finfo__t.html#acfed83ab2943ee7a58a215aa1cfd9e47',1,'apr_finfo_t']]],
  ['free_5findex_15',['free_index',['../structapr__memnode__t.html#af63769f30f6eb9d72e4b24050bd7a9d9',1,'apr_memnode_t']]],
  ['functions_20for_20manipulating_20the_20environment_16',['Functions for manipulating the environment',['../group__apr__env.html',1,'']]]
];
